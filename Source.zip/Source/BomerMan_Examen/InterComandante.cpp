// Fill out your copyright notice in the Description page of Project Settings.


#include "InterComandante.h"

// Add default functionality here for any IInterComandante functions that are not pure virtual.
