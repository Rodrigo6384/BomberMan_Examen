// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InterComandante.h"
#include "GameFramework/Actor.h"
#include "Comandante.generated.h"

UCLASS()
class BOMERMAN_EXAMEN_API AComandante : public AActor, public IInterComandante {
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AComandante();
	UStaticMeshComponent* MallaComandante;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	void DarOrdenes();
    void Estrategia();
};
