// Fill out your copyright notice in the Description page of Project Settings.


#include "InterMuros.h"

// Add default functionality here for any IInterMuros functions that are not pure virtual.
