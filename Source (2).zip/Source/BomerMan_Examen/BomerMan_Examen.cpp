// Copyright Epic Games, Inc. All Rights Reserved.

#include "BomerMan_Examen.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BomerMan_Examen, "BomerMan_Examen" );
 