// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MuroBase.h"
#include "MuroMadera.generated.h"

/**
 * 
 */
UCLASS()
class BOMERMAN_EXAMEN_API AMuroMadera : public AMuroBase
{
	GENERATED_BODY()
public:
	// Constructor
	AMuroMadera();
	void AccionIndividual() override;
	void AccionGrupal() override;
};
