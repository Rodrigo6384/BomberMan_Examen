// Fill out your copyright notice in the Description page of Project Settings.


#include "InterEnemigo.h"

// Add default functionality here for any IInterEnemigo functions that are not pure virtual.
